package com.main;

import com.ul.MyFrame;

public class SoftsysMain {
	public static void main(String[] args){
		new MyFrame();
	}
}
