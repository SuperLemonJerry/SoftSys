package com.nouse;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.data.Report;

public class QueryPanel extends JPanel{
	public QueryPanel(){
		this.setSize(600, 550);
		this.setVisible(true);
		this.setLayout(null);
		
		init();
	}
	
	public void init(){
		
		JLabel fOrderLb = new JLabel("һ������");
		fOrderLb.setBounds(50, 30, 65, 30);
		fOrderLb.setBackground(Color.gray);
		fOrderLb.setOpaque(true);
		this.add(fOrderLb);
		
		JLabel sOrderLb = new JLabel("��������");
		sOrderLb.setBounds(300, 30, 65, 30);
		sOrderLb.setBackground(Color.gray);
		sOrderLb.setOpaque(true);
		this.add(sOrderLb);
		
		JLabel softNameLb = new JLabel("��������");
		softNameLb.setBounds(140, 140, 55, 30);
		softNameLb.setBackground(Color.gray);
		softNameLb.setOpaque(true);
		this.add(softNameLb);
		
		JLabel teamNameLb = new JLabel("�����Ŷӣ�");
		teamNameLb.setBounds(140, 140, 55, 30);
		teamNameLb.setBackground(Color.gray);
		teamNameLb.setOpaque(true);
		this.add(teamNameLb);
			
		JComboBox CbFOrder = new JComboBox();
		CbFOrder.setBounds(120, 30, 150, 30);
		CbFOrder.setBackground(Color.gray);
		CbFOrder.setOpaque(true);
		this.add(CbFOrder);
		
		JComboBox CbSOrder = new JComboBox();
		CbSOrder.setBounds(370, 30, 150, 30);
		CbSOrder.setBackground(Color.gray);
		CbSOrder.setOpaque(true);
		this.add(CbSOrder);
		
		JButton jbOrder = new JButton("����");
		jbOrder.setBounds(540, 30, 45, 30);
		jbOrder.setBackground(Color.RED);
		jbOrder.setOpaque(true);
		this.add(jbOrder);
		
		JButton jbSearch = new JButton("����");
		jbSearch.setBounds(120, 300, 60, 30);
		jbSearch.setBackground(Color.RED);
		jbSearch.setOpaque(true);
		this.add(jbSearch);
		
		JTable resultTab = new JTable();
		Report report = new Report();
		resultTab.setModel(new DefaultTableModel(report.rowData , report.columnNames));
		JScrollPane jScrollPane = new JScrollPane(resultTab);
		this.add(jScrollPane);
		
		
	}
}
