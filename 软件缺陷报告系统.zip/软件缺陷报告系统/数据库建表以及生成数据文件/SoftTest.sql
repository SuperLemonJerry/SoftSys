create database SoftTest
go
use Softtest
go
create table user_table(
id int identity(1,1) primary key 
,uName varchar(20) not null
,pw varchar(20) not null 
)

create table report_table(
id int identity(1,1) primary key 
,softName varchar(20) not null
,softVersion varchar(20) not null
,modelName varchar(20)
,modelUnitName varchar(20)
,teamName varchar(20) not null
,testName varchar(20) not null
,testTime varchar(20) 
,severity varchar(20) 
,priority varchar(20)
,softProblem varchar(100) not null
)

go

insert into user_table values ('root','123456')

insert into report_table(softName,softVersion,teamName,testName,softProblem)values('΢��','3.3.02','΢�ſ����Ŷ�','С��','��¼������Ӧ�ٶ�')
insert into report_table(softName,softVersion,teamName,testName,softProblem)values('�ҵ�����','1.9.2','����','С��','װ�����ش���')  